--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.10
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE desafiobridge;
--
-- Name: desafiobridge; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE desafiobridge WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE desafiobridge OWNER TO postgres;

\connect desafiobridge

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tbcategoriaproduto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbcategoriaproduto (
    capcodigo integer NOT NULL,
    catcodigo integer NOT NULL,
    procodigo integer NOT NULL
);


ALTER TABLE public.tbcategoriaproduto OWNER TO postgres;

--
-- Name: tbcategorias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbcategorias (
    catcodigo integer NOT NULL,
    catnome character varying(255) NOT NULL,
    catnumprodutos integer DEFAULT 0
);


ALTER TABLE public.tbcategorias OWNER TO postgres;

--
-- Name: tbpedidoproduto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbpedidoproduto (
    pepcodigo integer NOT NULL,
    pedcodigo integer NOT NULL,
    procodigo integer NOT NULL
);


ALTER TABLE public.tbpedidoproduto OWNER TO postgres;

--
-- Name: tbpedidos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbpedidos (
    pedcodigo integer NOT NULL,
    pedcliente character varying(255) NOT NULL,
    pedata date DEFAULT now() NOT NULL,
    pedendereco character varying(255) NOT NULL,
    pedpreco numeric(14,2) DEFAULT 0 NOT NULL
);


ALTER TABLE public.tbpedidos OWNER TO postgres;

--
-- Name: tbprodutos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbprodutos (
    procodigo integer NOT NULL,
    pronome character varying(255) NOT NULL,
    prodescricao character varying(255) NOT NULL,
    propreco numeric(14,2) NOT NULL,
    pedcodigo integer
);


ALTER TABLE public.tbprodutos OWNER TO postgres;

--
-- Data for Name: tbcategoriaproduto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbcategoriaproduto (capcodigo, catcodigo, procodigo) FROM stdin;
\.
COPY public.tbcategoriaproduto (capcodigo, catcodigo, procodigo) FROM '$$PATH$$/3019.dat';

--
-- Data for Name: tbcategorias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbcategorias (catcodigo, catnome, catnumprodutos) FROM stdin;
\.
COPY public.tbcategorias (catcodigo, catnome, catnumprodutos) FROM '$$PATH$$/3018.dat';

--
-- Data for Name: tbpedidoproduto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbpedidoproduto (pepcodigo, pedcodigo, procodigo) FROM stdin;
\.
COPY public.tbpedidoproduto (pepcodigo, pedcodigo, procodigo) FROM '$$PATH$$/3020.dat';

--
-- Data for Name: tbpedidos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbpedidos (pedcodigo, pedcliente, pedata, pedendereco, pedpreco) FROM stdin;
\.
COPY public.tbpedidos (pedcodigo, pedcliente, pedata, pedendereco, pedpreco) FROM '$$PATH$$/3016.dat';

--
-- Data for Name: tbprodutos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbprodutos (procodigo, pronome, prodescricao, propreco, pedcodigo) FROM stdin;
\.
COPY public.tbprodutos (procodigo, pronome, prodescricao, propreco, pedcodigo) FROM '$$PATH$$/3017.dat';

--
-- Name: tbcategoriaproduto pk_tbcategoriaproduto; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbcategoriaproduto
    ADD CONSTRAINT pk_tbcategoriaproduto PRIMARY KEY (capcodigo);


--
-- Name: tbcategorias pk_tbcategorias; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbcategorias
    ADD CONSTRAINT pk_tbcategorias PRIMARY KEY (catcodigo);


--
-- Name: tbpedidoproduto pk_tbpedidoproduto; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbpedidoproduto
    ADD CONSTRAINT pk_tbpedidoproduto PRIMARY KEY (pepcodigo);


--
-- Name: tbpedidos pk_tbpedidos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbpedidos
    ADD CONSTRAINT pk_tbpedidos PRIMARY KEY (pedcodigo);


--
-- Name: tbprodutos pk_tbprodutos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbprodutos
    ADD CONSTRAINT pk_tbprodutos PRIMARY KEY (procodigo);


--
-- Name: tbpedidoproduto tbpedidoproduto_procodigo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbpedidoproduto
    ADD CONSTRAINT tbpedidoproduto_procodigo_key UNIQUE (procodigo);


--
-- Name: tbcategoriaproduto fk_tbcategoriaproduto_tbcategorias; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbcategoriaproduto
    ADD CONSTRAINT fk_tbcategoriaproduto_tbcategorias FOREIGN KEY (catcodigo) REFERENCES public.tbcategorias(catcodigo);


--
-- Name: tbcategoriaproduto fk_tbcategoriaproduto_tbprodutos; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbcategoriaproduto
    ADD CONSTRAINT fk_tbcategoriaproduto_tbprodutos FOREIGN KEY (procodigo) REFERENCES public.tbprodutos(procodigo);


--
-- Name: tbpedidoproduto fk_tbpedidoproduto_tbpedidos; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbpedidoproduto
    ADD CONSTRAINT fk_tbpedidoproduto_tbpedidos FOREIGN KEY (pedcodigo) REFERENCES public.tbpedidos(pedcodigo);


--
-- Name: tbpedidoproduto fk_tbpedidoproduto_tbprodutos; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbpedidoproduto
    ADD CONSTRAINT fk_tbpedidoproduto_tbprodutos FOREIGN KEY (procodigo) REFERENCES public.tbprodutos(procodigo);


--
-- Name: tbprodutos fk_tbprodutos_tbpedidos; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbprodutos
    ADD CONSTRAINT fk_tbprodutos_tbpedidos FOREIGN KEY (pedcodigo) REFERENCES public.tbpedidos(pedcodigo);


--
-- PostgreSQL database dump complete
--

